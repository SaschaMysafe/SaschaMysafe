This is a placeholder for locations.js
